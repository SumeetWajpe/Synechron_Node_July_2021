let EventEmitter = require("events").EventEmitter;
let evt = new EventEmitter();
// publisher logic
function GetCount(maxIteration) {
  // bix logic
  // emit start event -> when loop starts
  // emit count event -> pass current iteration count
  // emit finish event -> done !
  process.nextTick(function () {
    console.log("Emitting Start !");
    evt.emit("start");
    let cnt = 0;
    let timerId = setInterval(function () {
      evt.emit("count", ++cnt);
      if (cnt == 8) {
        evt.emit("error", cnt);
        clearInterval(timerId);
      }

      if (cnt == maxIteration) {
        evt.emit("finished", cnt);
        clearInterval(timerId);
      }
    }, 500);
  });
  return evt;
}
// subscriber logic
let e = GetCount(10);
e.on("start", function () {
  console.log("Iteration Started");
});
e.on("count", function (currCount) {
  console.log("Current Count : " + currCount);
});

e.on("error", function (count) {
  console.log("Finished with Error Count : " + count);
});

e.on("finished", function (finalCount) {
  console.log("Finished with Final Count : " + finalCount);
});

console.log("Listener Registered !");
