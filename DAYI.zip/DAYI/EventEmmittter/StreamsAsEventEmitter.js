var fs = require("fs");

let readableStream = fs.createReadStream("Input.txt");
let writeableStream = fs.createWriteStream("Output.txt");

let allData = "";

readableStream.on("data", function (chunk) {
  allData += chunk;
  console.log(">>>>>>>>>>>>>> CHUNK >>>>>>>>>>>>>>>>>>");
});

readableStream.on("end", function () {
  writeableStream.write(allData);
  writeableStream.end();
});

// OR
// readableStream.pipe(writeableStream);
