var fs = require("fs");

// Non-blocking code
fs.readFile("Input.txt", function (err, dataFromTheFile) {
  if (err) console.log(err);
  else console.log("Read file (Async) : " + dataFromTheFile.toString());
});

// Blocking Code
// var dataFromTheFile = fs.readFileSync("Input.txt");
// console.log("Read file (Sync) : " + dataFromTheFile.toString());

console.log("Program Ended !");
