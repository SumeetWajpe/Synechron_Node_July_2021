const { constants } = require("buffer");
var fs = require("fs");

fs.mkdir("temp", function (err) {
  if (err) {
  } else {
    fs.access("temp", fs.constants.F_OK, (err) => {
      process.chdir("temp");
      fs.writeFile(
        "Test.txt",
        "This is a message to be written to Test.txt",
        function (err) {
          if (err) {
          } else {
            fs.readFile("Test.txt", (err, data) => {
              console.log(data.toString());
            });
          }
        }
      );
    });
  }
});
