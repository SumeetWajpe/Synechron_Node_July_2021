function Add(x, y) {
  return x + y;
}
const PI = 3.14;

// module.exports.Add = Add;
// module.exports.PI = PI;

module.exports = {
  Addition: Add,
  PI,
};
