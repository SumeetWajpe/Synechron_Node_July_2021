// var axiosget = require('axios').default.get;
var axios = require("axios").default;

let aPromise = axios.get("https://jsonplaceholder.typicode.com/posts");
aPromise
  .then((response) => console.log(response))
  .catch((err) => console.log(err));
