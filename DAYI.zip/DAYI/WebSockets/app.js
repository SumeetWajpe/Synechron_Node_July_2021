const http = require("http");
var socket = require("socket.io");
const fs = require("fs");

const hostname = "127.0.0.1";
const port = 3000;

const server = http.createServer((req, res) => {
  console.log("Request Handled !");
  res.statusCode = 200;
  res.setHeader("Content-Type", "text/html");

  fs.readFile("ClientPeer.html", function (err, datafromTheFile) {
    res.end(datafromTheFile);
  });
});

var io = socket(server); // socket reg on server
io.sockets.on("connection", function (skt) {
  // send / emit event / msg to Client Peer !
  setInterval(function () {
    var dataToBeSent = new Date();
    skt.emit("custom_message_from_serverpeer", dataToBeSent);
  }, 2000);

  skt.on("custom_message_from_clientpeer", function (dataFromClientPeer) {
    console.log("Data From Client Peer : " + dataFromClientPeer);
  });
});

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});
