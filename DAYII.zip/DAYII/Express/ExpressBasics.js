let express = require("express");
let app = express(); // represents our application

app.get("/", (req, res) => {
  //   let products = [
  //     { name: "LED TV", price: 40000 },
  //     { name: "LCD TV", price: 50000 },
  //     { name: "OLED TV", price: 60000 },
  //     { name: "Curved OLED TV", price: 100000 },
  //   ];
  // res.set("Content-Type", "application/json");
  // res.json(products);
  //res.send("<h1>Hello from Express JS!!</h1>");
  res.sendFile("Index.html", { root: __dirname });
});

app.listen(5000, () => console.log("Server listening @ port 5000 !"));
