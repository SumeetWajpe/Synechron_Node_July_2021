let express = require("express");
let app = express(); /// app object

app.use(express.urlencoded({ extended: true }));

app.get("/", (req, res) => {
  res.sendFile("Login.html", { root: __dirname });
});

app.post("/login", (req, res) => {
  // get details from the client
  console.log(req.body.username);
  console.log(req.body.password);

  res.send("success");
});

app.use((req, res) => {
  res.statusCode = 404;
  // sendFile()
  res.send(
    "<h1 style='color:red;border:2px solid red;'> Resource Not Found ! </h1>"
  );
});

app.listen(5000, () => console.log("Server listening @ port 5000 !"));
