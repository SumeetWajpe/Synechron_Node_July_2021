let express = require("express");
let app = express(); /// app object
let router = require("./productsRoutes");

app.use("/", router);
app.get("/", (req, res) => {
  res.sendFile("Index.html", { root: __dirname });
});

// last in the order
app.use((req, res) => {
  res.statusCode = 404;
  // sendFile()
  res.send(
    "<h1 style='color:red;border:2px solid red;'> Resource Not Found ! </h1>"
  );
});

app.listen(5000, () => console.log("Server listening @ port 5000 !"));
