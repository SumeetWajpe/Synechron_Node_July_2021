let express = require("express");
let router = express.Router();
// router.route("/products").get((req, res) => {
//   let products = [
//     { name: "LED TV", price: 40000 },
//     { name: "LCD TV", price: 50000 },
//     { name: "OLED TV", price: 60000 },
//     { name: "Curved OLED TV", price: 100000 },
//   ];
//   res.json(products);
// });

router.route("/products/:pid").get((req, res) => {
  let products = [
    { id: 1, name: "LED TV", price: 40000 },
    { id: 2, name: "LCD TV", price: 50000 },
    { id: 3, name: "OLED TV", price: 60000 },
    { id: 4, name: "Curved OLED TV", price: 100000 },
  ];
  //   let pId = req.params.pid;
  // ES6 destructuring
  let {
    params: { pid },
  } = req;
  //   console.log("Pid : " + pid);
  let theProduct = products.find((p) => p.id == pid);
  if (theProduct) {
    res.json(theProduct);
  } else {
    res.json(products);
  }
});

module.exports = router;
