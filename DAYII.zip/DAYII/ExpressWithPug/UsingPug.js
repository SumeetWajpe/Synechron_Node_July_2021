let express = require("express");
let app = express(); // represents our application
let path = require("path");
let router = require("./routes/index");
let productrouter = require("./routes/products");

app.set("views", path.join(__dirname, "views"));
app.set("view engine", "pug");
app.use("/", router);
app.use("/", productrouter);

app.get("/", (req, res) => {
  res.send("<h1>Use /index to see some HTML !</h1>");
});

app.listen(5000, () => console.log("Server listening @ port 5000 !"));
