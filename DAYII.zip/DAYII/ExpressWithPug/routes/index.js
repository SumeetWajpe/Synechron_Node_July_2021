let express = require("express");
let router = express.Router();

router.route("/index").get((req, res) => {
  // render a pug file
  res.render("index", { message: "Rendered using Pug Engine !" });
});

module.exports = router;
