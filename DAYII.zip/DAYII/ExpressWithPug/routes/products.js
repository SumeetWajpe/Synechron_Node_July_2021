let express = require("express");
let router = express.Router();

router.route("/products").get((req, res) => {
  let products = [
    { id: 1, name: "LED TV", price: 40000 },
    { id: 2, name: "LCD TV", price: 50000 },
    { id: 3, name: "OLED TV", price: 60000 },
    { id: 4, name: "Curved OLED TV", price: 100000 },
  ];
  res.render("products", { products, title: "List Of Products !" });
  //   res.json(products);
});

module.exports = router;
