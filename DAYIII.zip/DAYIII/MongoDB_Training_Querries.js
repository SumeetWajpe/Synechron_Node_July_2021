// db.products.insertOne({})
db.products.insertMany([
  {
    _id: 1,
    title: "Laptop",
    price: 50000,
    rating: 5,
    likes: 4000,
    quantity: 10,
  },
  { _id: 2, title: "LED TV", price: 40000, rating: 4, likes: 400, quantity: 5 },
  {
    _id: 3,
    title: "Mobile",
    price: 20000,
    rating: 5,
    likes: 1000,
    quantity: 10,
  },
  { _id: 4, title: "Watch", price: 5000, rating: 3, likes: 400, quantity: 100 },
]);

// Updating one record
db.products.updateOne({ title: "Laptop" }, { $set: { price: 70000 } });

db.products.updateMany({}, { $set: { rating: 5 } });

//projection
db.products.find({ price: { $gt: 10000 } }, { _id: 0 });

// embedded documents
db.products.insertOne({
  _id: 5,
  title: "Camera",
  price: 90000,
  rating: 3,
  likes: 400,
  quantity: 20,
  distributor: { name: "CY Retailers", location: "Pune" },
});

db.products.find({}, { _id: 0 }).limit(2);
db.products.find({}, { _id: 0 }).sort({ price: 1 }); // ascending order


mongoimport --db synusersdb --collection users --file users.json --jsonArray

// implicit AND
db.users.find({ "dob.age": { $gt: 50 }, "nat": "DE" })


// using $or
db.users.find({ $or: [{ "dob.age": { $gt: 50 } }, { "nat": "DE" }] }).limit(5).pretty()

//  Aggregation pipeline

db.users.aggregate([
    { $match: { "gender": "male" } },
    { $group: { _id: { nat: "$nat" }, "userCount": { $sum: 1 } } },
    {$sort:{"userCount":1}}
])

