var express = require("express");
var router = express.Router();
var mongodb = require("mongodb");

/* GET home page. */
router.get("/", function (req, res, next) {
  res.render("index", { title: "Express" });
});

// router.get("/products", (req, res) => {
//   // 1. connect to db [connection string->server->port,ip address]
//   //2. access the db / collection
//   //3. find the records
//   //4. render the records.
//   var MongoClient = mongodb.MongoClient;
//   var url = "mongodb://localhost:27017";
//   MongoClient.connect(url, { useNewUrlParser: true }, (err, dbconn) => {
//     if (err) {
//       console.log(err);
//     } else {
//       // console.log(dbconn);
//       let collection = dbconn.db("productsdb").collection("products");
//       collection.find({}).toArray((err, result) => {
//         if (err) {
//           console.log(err);
//         } else {
//           console.log(result.length);
//           res.render("products", { products: result });
//         }
//       });
//     }
//   });
// });

router.post("/addnewproduct", function (req, res) {
  // fetch data from request & insert in DB
  // collection.insertOne({newProduct})
});
router.get("/productlist", function (req, res, next) {
  var MongoClient = mongodb.MongoClient;
  var url = "mongodb://localhost:27017";
  MongoClient.connect(url, { useNewUrlParser: true }, (err, dbconn) => {
    if (err) {
      console.log(err);
    } else {
      // console.log(dbconn);
      let collection = dbconn.db("productsdb").collection("products");
      collection.find({}).toArray((err, result) => {
        if (err) {
          console.log(err);
        } else {
          console.log(result.length);
          res.json(result);
        }
      });
    }
  });
});

module.exports = router;
